# ReachInbox – Full-stack Email Job Scheduler

A production-style assignment implementation using React + TypeScript, Express + TypeScript, PostgreSQL, Redis/BullMQ, Elasticsearch, Ethereal SMTP, Google OAuth and Slack OAuth.

## Architecture

```text
React Dashboard
      |
      v
Express API ---- PostgreSQL (persistent email state)
      |
      +---- Redis <---- BullMQ Queue <---- Worker
      |                                  |
      |                                  +---- Redis-backed rate limiting
      |                                  +---- Ethereal SMTP
      |                                  +---- Elasticsearch indexing
      |                                  +---- Slack notification
      |
      +---- Google OAuth / Slack OAuth
```

## Key decisions

- No cron jobs or cron libraries are used.
- Every email is persisted in PostgreSQL before its BullMQ delayed job is created.
- BullMQ uses Redis-backed delayed jobs, so future jobs survive application restarts.
- Each email has a stable `email:<id>` BullMQ job ID to prevent duplicate queue entries.
- Worker concurrency is configurable with `WORKER_CONCURRENCY`.
- Minimum inter-send delay is configurable with `MIN_DELAY_MS`.
- Hourly rate limiting is implemented with an atomic Redis Lua script per sender/hour window. Jobs are rescheduled rather than dropped.
- A rate-limit hit triggers a real Slack API notification when Slack is connected.
- Email records are indexed in Elasticsearch and can be searched through `/api/emails/search`.
- Bull Board is mounted at `/admin/queues`.

> SMTP providers cannot generally provide an absolute exactly-once guarantee across a network failure occurring after SMTP accepts a message but before the application records success. The implementation uses durable state, stable IDs, and idempotency checks to minimize duplicate sends and documents this trade-off.

## Services

Docker Compose starts:
- PostgreSQL
- Redis
- Elasticsearch

The Node API and worker run locally.

## 1. Prerequisites

- Node.js 20+
- npm 10+
- Docker Desktop
- Git
- Google OAuth credentials
- Slack OAuth app credentials
- Ethereal account/credentials

## 2. Start infrastructure

```bash
docker compose up -d
```

Check:

```bash
docker compose ps
```

## 3. Backend

```bash
cd backend
npm install
cp .env.example .env
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```

In a second terminal:

```bash
cd backend
npm run worker
```

Backend: `http://localhost:4000`

Bull Board: `http://localhost:4000/admin/queues`

## 4. Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend: `http://localhost:5173`

## Environment

See `backend/.env.example`.

For local development, Google OAuth callback is:

`http://localhost:4000/auth/google/callback`

Slack OAuth callback is:

`http://localhost:4000/auth/slack/callback`

Set the same values in your Google/Slack developer consoles.

## Demo flow

1. Login with Google.
2. Open Compose.
3. Enter subject/body.
4. Upload a CSV containing email addresses.
5. Choose start time, delay and hourly limit.
6. Schedule.
7. Observe delayed jobs in Bull Board.
8. Observe Scheduled Emails.
9. Worker sends through Ethereal.
10. Observe Sent Emails.
11. Stop/restart API and worker before a future job is due; the delayed job remains in Redis and is processed after restart.
12. Set a low hourly limit for a demo and connect Slack. When the limit is reached, a Slack notification is sent and remaining jobs are rescheduled.

## API summary

- `GET /health`
- `GET /auth/google`
- `GET /auth/me`
- `POST /auth/logout`
- `GET /auth/slack`
- `GET /auth/slack/status`
- `POST /auth/slack/disconnect`
- `POST /api/emails/schedule`
- `GET /api/emails?status=scheduled`
- `GET /api/emails?status=sent`
- `GET /api/emails/search?q=...`

## Assumptions / trade-offs

- A campaign uses the authenticated user's configured sender email.
- CSV parsing accepts common CSV/text formats and extracts email-looking tokens.
- Ethereal is intentionally used as a fake SMTP provider; generated preview URLs are logged by the worker.
- Slack OAuth tokens are stored in PostgreSQL for the assignment. For a production system they should be encrypted at rest and rotated.
- Google OAuth uses a signed session cookie backed by the database.
