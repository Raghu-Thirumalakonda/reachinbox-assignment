import { useEffect, useState } from "react";
import { Mail, LogOut, Plus, Search, Send, Clock3, Link2, Unlink2, Upload, X } from "lucide-react";
import toast from "react-hot-toast";
import { api, API } from "./api";
import type { EmailJob, User } from "./types";

function Login() {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-5">
      <div className="w-full max-w-[390px] border border-gray-200 rounded-lg p-8 shadow-sm">
        <div className="text-center mb-8">
          <div className="mx-auto mb-4 h-11 w-11 rounded-xl bg-green-50 flex items-center justify-center">
            <Mail className="text-brand" size={21} />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Login</h1>
          <p className="text-sm text-gray-500 mt-2">Sign in to manage your email schedules.</p>
        </div>
        <a
          href={`${API}/auth/google`}
          className="w-full flex items-center justify-center gap-3 border border-gray-200 rounded-md h-11 text-sm font-medium hover:bg-gray-50 transition"
        >
          <span className="font-bold">G</span>
          Continue with Google
        </a>
      </div>
    </div>
  );
}

function Header({ user, onLogout }: { user: User; onLogout: () => void }) {
  return (
    <header className="h-16 border-b border-gray-200 flex items-center justify-between px-7">
      <div className="flex items-center gap-2 font-semibold">
        <div className="h-8 w-8 rounded-lg bg-brand text-white flex items-center justify-center">
          <Mail size={17} />
        </div>
        ReachInbox
      </div>
      <div className="flex items-center gap-4">
        <div className="hidden sm:block text-right">
          <div className="text-sm font-medium">{user.name}</div>
          <div className="text-xs text-gray-500">{user.email}</div>
        </div>
        {user.avatar ? (
          <img src={user.avatar} className="h-9 w-9 rounded-full border" />
        ) : (
          <div className="h-9 w-9 rounded-full bg-gray-100 flex items-center justify-center text-sm font-semibold">
            {user.name.charAt(0)}
          </div>
        )}
        <button onClick={onLogout} className="text-gray-500 hover:text-gray-900" title="Logout">
          <LogOut size={18} />
        </button>
      </div>
    </header>
  );
}

function StatusPill({ status }: { status: EmailJob["status"] }) {
  const cls =
    status === "SENT" ? "bg-green-50 text-green-700" :
    status === "FAILED" ? "bg-red-50 text-red-700" :
    status === "PROCESSING" ? "bg-blue-50 text-blue-700" :
    "bg-gray-100 text-gray-700";
  return <span className={`px-2 py-1 rounded-full text-xs font-medium ${cls}`}>{status.toLowerCase()}</span>;
}

function EmailTable({ emails, sent }: { emails: EmailJob[]; sent?: boolean }) {
  if (!emails.length) {
    return (
      <div className="border border-dashed border-gray-300 rounded-xl py-20 text-center">
        {sent ? <Send className="mx-auto text-gray-300" /> : <Clock3 className="mx-auto text-gray-300" />}
        <p className="mt-3 text-sm font-medium">No {sent ? "sent" : "scheduled"} emails</p>
        <p className="text-xs text-gray-400 mt-1">Your email activity will appear here.</p>
      </div>
    );
  }

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="text-left font-medium text-gray-500 px-5 py-3">Email</th>
              <th className="text-left font-medium text-gray-500 px-5 py-3">Subject</th>
              <th className="text-left font-medium text-gray-500 px-5 py-3">{sent ? "Sent time" : "Scheduled time"}</th>
              <th className="text-left font-medium text-gray-500 px-5 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {emails.map((email) => (
              <tr key={email.id} className="hover:bg-gray-50/70">
                <td className="px-5 py-4 whitespace-nowrap">{email.recipient}</td>
                <td className="px-5 py-4 max-w-[340px] truncate">{email.subject}</td>
                <td className="px-5 py-4 whitespace-nowrap text-gray-600">
                  {new Date(sent && email.sentAt ? email.sentAt : email.scheduledAt).toLocaleString()}
                </td>
                <td className="px-5 py-4"><StatusPill status={email.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Compose({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [recipients, setRecipients] = useState<string[]>([]);
  const [startAt, setStartAt] = useState("");
  const [delay, setDelay] = useState(2000);
  const [hourlyLimit, setHourlyLimit] = useState(100);
  const [loading, setLoading] = useState(false);

  const upload = async (file?: File) => {
    if (!file) return;
    try {
      const result = await api.parseCsv(file);
      setRecipients(result.emails);
      toast.success(`${result.count} email addresses detected`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not parse file");
    }
  };

  const schedule = async () => {
    if (!subject || !body || !recipients.length || !startAt) {
      toast.error("Complete subject, body, recipients and start time");
      return;
    }
    setLoading(true);
    try {
      await api.schedule({
        subject,
        body,
        recipients,
        startAt: new Date(startAt).toISOString(),
        delayMs: delay,
        hourlyLimit
      });
      toast.success(`${recipients.length} emails scheduled`);
      onDone();
      onClose();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Scheduling failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/20 z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl max-h-[92vh] overflow-auto rounded-xl border shadow-xl">
        <div className="h-14 px-5 border-b flex items-center justify-between">
          <div className="font-semibold">Compose New Email</div>
          <button onClick={onClose}><X size={19} /></button>
        </div>
        <div className="p-6 space-y-5">
          <div className="grid sm:grid-cols-2 gap-4">
            <label className="text-sm">
              <span className="block text-gray-500 mb-1">Subject</span>
              <input value={subject} onChange={e => setSubject(e.target.value)} className="w-full h-10 border rounded-md px-3 outline-none focus:ring-2 focus:ring-green-100" placeholder="Your subject" />
            </label>
            <label className="text-sm">
              <span className="block text-gray-500 mb-1">Lead file</span>
              <label className="h-10 border border-dashed rounded-md px-3 flex items-center gap-2 cursor-pointer hover:bg-gray-50">
                <Upload size={16} />
                <span>{recipients.length ? `${recipients.length} emails detected` : "Upload CSV / TXT"}</span>
                <input type="file" accept=".csv,.txt,text/csv,text/plain" className="hidden" onChange={e => upload(e.target.files?.[0])} />
              </label>
            </label>
          </div>

          <div className="text-sm text-gray-500">
            Recipients: <span className="font-medium text-gray-800">{recipients.length}</span>
            {recipients.length > 0 && <span className="ml-2 text-xs">({recipients.slice(0, 4).join(", ")}{recipients.length > 4 ? "…" : ""})</span>}
          </div>

          <label className="text-sm block">
            <span className="block text-gray-500 mb-1">Email body</span>
            <textarea value={body} onChange={e => setBody(e.target.value)} rows={10} className="w-full border rounded-md p-3 outline-none focus:ring-2 focus:ring-green-100 resize-y" placeholder="Write your email..." />
          </label>

          <div className="grid md:grid-cols-3 gap-4">
            <label className="text-sm">
              <span className="block text-gray-500 mb-1">Start time</span>
              <input type="datetime-local" value={startAt} onChange={e => setStartAt(e.target.value)} className="w-full h-10 border rounded-md px-3" />
            </label>
            <label className="text-sm">
              <span className="block text-gray-500 mb-1">Delay between emails (ms)</span>
              <input type="number" min={0} value={delay} onChange={e => setDelay(Number(e.target.value))} className="w-full h-10 border rounded-md px-3" />
            </label>
            <label className="text-sm">
              <span className="block text-gray-500 mb-1">Hourly limit</span>
              <input type="number" min={1} value={hourlyLimit} onChange={e => setHourlyLimit(Number(e.target.value))} className="w-full h-10 border rounded-md px-3" />
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button onClick={onClose} className="px-4 h-10 border rounded-md text-sm">Cancel</button>
            <button disabled={loading} onClick={schedule} className="px-5 h-10 rounded-md bg-brand text-white text-sm font-medium disabled:opacity-60">
              {loading ? "Scheduling..." : "Schedule"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Dashboard({ user, onLogout }: { user: User; onLogout: () => void }) {
  const [tab, setTab] = useState<"scheduled" | "sent">("scheduled");
  const [emails, setEmails] = useState<EmailJob[]>([]);
  const [search, setSearch] = useState("");
  const [compose, setCompose] = useState(false);
  const [slackConnected, setSlackConnected] = useState(false);

  const load = async () => {
    try {
      const data = tab === "scheduled" ? await api.scheduled() : await api.sent();
      setEmails(data);
    } catch (e) {
      if (e instanceof Error && e.message.includes("Authentication")) onLogout();
      else toast.error("Could not load emails");
    }
  };

  useEffect(() => { load(); }, [tab]);

  useEffect(() => {
    api.slackStatus().then(x => setSlackConnected(x.connected)).catch(() => {});
  }, []);

  const doSearch = async () => {
    if (!search.trim()) return load();
    try { setEmails(await api.search(search)); }
    catch { toast.error("Search failed"); }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header user={user} onLogout={onLogout} />
      <div className="flex min-h-[calc(100vh-64px)]">
        <aside className="w-60 border-r hidden md:block p-4">
          <button onClick={() => setCompose(true)} className="w-full h-10 rounded-md bg-brand text-white text-sm font-medium flex items-center justify-center gap-2">
            <Plus size={16} /> Compose New Email
          </button>
          <div className="mt-7 space-y-1">
            <button onClick={() => setTab("scheduled")} className={`w-full text-left px-3 py-2.5 rounded-md text-sm ${tab === "scheduled" ? "bg-green-50 text-brand font-medium" : "text-gray-600 hover:bg-gray-50"}`}>
              Scheduled Emails
            </button>
            <button onClick={() => setTab("sent")} className={`w-full text-left px-3 py-2.5 rounded-md text-sm ${tab === "sent" ? "bg-green-50 text-brand font-medium" : "text-gray-600 hover:bg-gray-50"}`}>
              Sent Emails
            </button>
          </div>

          <div className="mt-10 border-t pt-5">
            <div className="text-xs text-gray-400 uppercase tracking-wide mb-3">Integrations</div>
            {slackConnected ? (
              <button onClick={async () => { await api.disconnectSlack(); setSlackConnected(false); toast.success("Slack disconnected"); }} className="w-full text-left px-3 py-2 text-sm flex items-center gap-2 text-gray-600 hover:bg-gray-50 rounded-md">
                <Unlink2 size={15} /> Disconnect Slack
              </button>
            ) : (
              <a href={`${API}/auth/slack`} className="w-full text-left px-3 py-2 text-sm flex items-center gap-2 text-gray-600 hover:bg-gray-50 rounded-md">
                <Link2 size={15} /> Connect Slack
              </a>
            )}
          </div>
        </aside>

        <main className="flex-1 p-5 md:p-8">
          <div className="md:hidden mb-4">
            <button onClick={() => setCompose(true)} className="w-full h-10 rounded-md bg-brand text-white text-sm font-medium">+ Compose New Email</button>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-7">
            <div>
              <h1 className="text-2xl font-semibold">{tab === "scheduled" ? "Scheduled Emails" : "Sent Emails"}</h1>
              <p className="text-sm text-gray-500 mt-1">{tab === "scheduled" ? "Emails waiting to be delivered." : "Delivery history and status."}</p>
            </div>
            <div className="flex gap-2">
              <div className="h-10 border rounded-md flex items-center px-3 gap-2 w-64">
                <Search size={16} className="text-gray-400" />
                <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={e => e.key === "Enter" && doSearch()} className="outline-none text-sm w-full" placeholder="Search emails..." />
              </div>
              <button onClick={doSearch} className="h-10 px-4 border rounded-md text-sm">Search</button>
            </div>
          </div>

          <EmailTable emails={emails} sent={tab === "sent"} />
        </main>
      </div>

      {compose && <Compose onClose={() => setCompose(false)} onDone={load} />}
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const loadUser = () => {
    api.me().then(setUser).catch(() => setUser(null)).finally(() => setLoading(false));
  };

  useEffect(loadUser, []);

  if (loading) return <div className="min-h-screen flex items-center justify-center text-sm text-gray-500">Loading...</div>;
  if (!user) return <Login />;

  return <Dashboard user={user} onLogout={async () => { await api.logout(); setUser(null); }} />;
}
