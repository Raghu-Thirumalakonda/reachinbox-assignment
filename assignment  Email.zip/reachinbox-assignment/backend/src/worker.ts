import { Worker, Job } from "bullmq";
import { redis } from "./lib/redis";
import { prisma } from "./lib/prisma";
import { emailQueue } from "./queue";
import { env } from "./config/env";
import { sendEmail } from "./services/mailer";
import { reserveHourlySlot } from "./services/rateLimiter";
import { sendSlackRateLimitNotification } from "./services/slack";
import { indexEmail } from "./services/elasticsearch";

async function processEmail(job: Job<{ emailId: string }>) {
  const email = await prisma.emailJob.findUnique({
    where: { id: job.data.emailId },
    include: { campaign: true }
  });

  if (!email) return;
  if (email.status === "SENT") return;

  const reservation = await reserveHourlySlot(
    email.senderEmail,
    Math.min(email.campaign.hourlyLimit, env.MAX_EMAILS_PER_HOUR)
  );

  if (!reservation.allowed) {
    await sendSlackRateLimitNotification(
      email.userId,
      email.senderEmail,
      Math.min(email.campaign.hourlyLimit, env.MAX_EMAILS_PER_HOUR)
    );

    await prisma.emailJob.update({
      where: { id: email.id },
      data: {
        scheduledAt: reservation.nextHour,
        status: "SCHEDULED"
      }
    });

    await emailQueue.add(
      "send-email",
      { emailId: email.id },
      {
        jobId: `email:${email.id}:retry:${reservation.nextHour.getTime()}`,
        delay: Math.max(1000, reservation.nextHour.getTime() - Date.now())
      }
    );

    return;
  }

  await prisma.emailJob.update({
    where: { id: email.id },
    data: { status: "PROCESSING", attempts: { increment: 1 } }
  });

  try {
    // Minimum delay between worker sends. Redis-backed rate limiting still protects
    // the hourly limit across multiple workers/instances.
    if (env.MIN_DELAY_MS > 0) {
      await new Promise(resolve => setTimeout(resolve, env.MIN_DELAY_MS));
    }

    const result = await sendEmail({
      from: email.senderEmail,
      fromName: env.DEFAULT_SENDER_NAME,
      to: email.recipient,
      subject: email.subject,
      html: email.body.replace(/\n/g, "<br />")
    });

    const sent = await prisma.emailJob.update({
      where: { id: email.id },
      data: {
        status: "SENT",
        sentAt: new Date(),
        messageId: result.messageId,
        previewUrl: result.previewUrl
      }
    });

    await indexEmail(sent);
    console.log(`Sent ${email.recipient}${result.previewUrl ? ` -> ${result.previewUrl}` : ""}`);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    await prisma.emailJob.update({
      where: { id: email.id },
      data: { status: "FAILED", lastError: message }
    });
    await indexEmail({
      ...email,
      status: "FAILED",
      sentAt: null
    });
    throw error;
  }
}

const worker = new Worker("email-scheduler", processEmail, {
  connection: redis,
  concurrency: env.WORKER_CONCURRENCY
});

worker.on("completed", job => console.log(`Job completed: ${job.id}`));
worker.on("failed", (job, err) => console.error(`Job failed: ${job?.id}`, err.message));

console.log(`Worker started with concurrency=${env.WORKER_CONCURRENCY}`);
