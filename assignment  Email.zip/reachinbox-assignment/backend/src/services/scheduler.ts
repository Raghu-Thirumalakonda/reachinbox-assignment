import { prisma } from "../lib/prisma";
import { emailQueue } from "../queue";

export async function enqueueEmailJob(emailId: string, scheduledAt: Date) {
  const delay = Math.max(0, scheduledAt.getTime() - Date.now());

  await emailQueue.add(
    "send-email",
    { emailId },
    {
      jobId: `email:${emailId}`,
      delay
    }
  );
}

export async function recoverMissingQueueJobs() {
  const scheduled = await prisma.emailJob.findMany({
    where: {
      status: "SCHEDULED",
      scheduledAt: { gte: new Date() }
    },
    orderBy: { scheduledAt: "asc" }
  });

  for (const email of scheduled) {
    try {
      await enqueueEmailJob(email.id, email.scheduledAt);
    } catch (error) {
      // A duplicate BullMQ job is safe to ignore during recovery.
      const message = error instanceof Error ? error.message : String(error);
      if (!message.toLowerCase().includes("jobid")) {
        console.error("Queue recovery failed:", email.id, error);
      }
    }
  }
}
