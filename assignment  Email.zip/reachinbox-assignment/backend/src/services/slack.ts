import axios from "axios";
import { prisma } from "../lib/prisma";
import { env } from "../config/env";

export async function sendSlackRateLimitNotification(userId: string, sender: string, limit: number) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user?.slackAccessToken) return;

  try {
    await axios.post(
      "https://slack.com/api/chat.postMessage",
      {
        channel: user.slackTeamId ? `@${user.email}` : user.email,
        text: `ReachInbox rate limit reached: sender ${sender} has reached ${limit} emails in the current hour. Remaining emails were rescheduled.`
      },
      { headers: { Authorization: `Bearer ${user.slackAccessToken}` } }
    );
  } catch (error) {
    console.error("Slack notification failed:", error);
  }
}

export function slackConfigured() {
  return Boolean(env.SLACK_CLIENT_ID && env.SLACK_CLIENT_SECRET && env.SLACK_REDIRECT_URI);
}
